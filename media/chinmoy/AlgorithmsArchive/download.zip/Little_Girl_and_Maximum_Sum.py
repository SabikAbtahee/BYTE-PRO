
import bisect

if __name__ == '__main__':
    n,q = input().strip().split()
    n,q = int(n), int(q)

    arr = [0]*10**5
    cum = [0]*10**5
    a  = list(map(int, input().split()))

    # for i in range(q)
# for i in range(1,n+1):
        # cum[i] = cum[i-1] + a[i-1]
#
