#include<bits/stdc++.h>
using namespace std;
int main(){
	chinmoy
	chinmoy
	sabik
	janina ki hbe
	jhvuvuvuvuvuasass
	ajk shokale
}assaasasasasassasasas
this is csaasasasasasasasasasasas
asaoiabsas\aS
assaasasasasassasasasaS
assaasasasasassasasasaSas
assaasasasasassasasasaSas
as
ajk shokaleasasas
this is csaasasasasasasasasasasas
asaoiabsas\aS
assaasasasasassasasasaS
assaasasasasassasasasaSas
assaasasasasassasasasaSas
as++++++++++