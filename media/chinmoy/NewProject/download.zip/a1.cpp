#include<stdio.h>asasassassddsdsdassaasasaasasasasasasasaasasaasasasasasasaasasasqwqwqw
int main(){
	print()

	
	print()
	print()

	//hello
	//hello
	//hello
	//hello
	//return 0;
	//return 0;
	asas
	asasas
	chinmoy
	wwe
	wwwe
	janina ki hbe
	janina ki hbe2
	janina ki hbe3
	janina ki hbe4
	janina ki hbe5
	return 0;
	chinmoyddsdssasasasasasasasasasasasaasasaasasaasasaassasasas
}
asasasassdsdsdasasasasasasasasasasasaasas