#include<bits/stdc++.h>
using namespace std;
int main(){
    string a="422";
    string b="42";

    cout<<(int)a-(int)b<<endl;
    return 0;

}
